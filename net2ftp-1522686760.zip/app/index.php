<?php
    /*
     * MVC sample benlitech
     * Entry point
     */
    include "sys/routes.php";
?>          